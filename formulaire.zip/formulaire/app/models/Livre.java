package models;

import java.util.Date;

import io.ebean.*;
import javax.persistence.*;

import play.data.validation.Constraints.*;

@Entity
public class Livre extends Model{
  
    private static final long serialVersionUID = 1L; 
    
    @Id
    private long id;
    
    @Required
    @Pattern(value="^[A-Z][a-z0-9 ]{2,}", message="le titre doit commencer par une majusucule")
    private String titre;
    @Required
    private String auteur;
    @Min(value=3, message="le livre doit avoir au moins 3 pages")
    private int nbPages;
    private Date dateEdition;
    
    public Livre(){
        this.titre="Le seigneur des anneaux";
        this.auteur="J.R.R. Tolkien";
        this.nbPages=10;
        this.dateEdition = null;
    }
    
    public String getTitre(){
        return this.titre;
    }
    
    public void setTitre(String titre){
        this.titre = titre;
    }
    
    public String getAuteur(){
        return auteur;
    }
    
    public Date getDateEdition(){
        return dateEdition;
    }
    
    public int getNbPages(){
        return nbPages;
    }
    
    public void setAuteur(String auteur){
        this.auteur=auteur;
    }
    
    public void setDateEdition(Date dateEdition){
        this.dateEdition = dateEdition;
    } 
    
    public void setNbPages(int nbPages){
        this.nbPages = nbPages;
    }
    
    public void setId(Long id){
        this.id = id;
    }
    
    public Long getId(){
        return this.id;
    }
    
    public static Finder<Long,Livre> find = new Finder<Long,Livre>(Livre.class);
    
}